mobile theme for phptemplate on Drupal
----------------------------------------

mobile is intended to return only clean HTML. 

It returns no tables, DIVs or other markup. The links and sidebars are placed
on such a place that mobile- or handheld-readers are useable on such devices.

Author
------
B�r Kessels 
Sponsored by http://www.webschuur.com
ber@webschuur.com
